    /*#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!
    !                                                                            #
    #                                                                            !
    !   Programmer:     Nick Martinez                                            #
    #   Class:          COSCI 436 - SAT 8:15 - 10:30AM                           !
    !   Instructor:     Milan Samplewala                                         #
    #   Date:           11/16/2018                                               !
    !                                                                            #
    #          LAB 8 - Min Heap                                                  !
    !                                                                            #
    #!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!



________/\\\\\\\\\_______/\\\\\__________/\\\\\\\\\\\__________/\\\\\\\\\__/\\\\\\\\\\\_        
_____/\\\////////______/\\\///\\\______/\\\/////////\\\_____/\\\////////__\/////\\\///__       
___/\\\/_____________/\\\/__\///\\\___\//\\\______\///____/\\\/_______________\/\\\_____      
__/\\\______________/\\\______\//\\\___\////\\\__________/\\\_________________\/\\\_____     
_\/\\\_____________\/\\\_______\/\\\______\////\\\______\/\\\_________________\/\\\_____    
_\//\\\____________\//\\\______/\\\__________\////\\\___\//\\\________________\/\\\_____   
__\///\\\___________\///\\\__/\\\_____/\\\______\//\\\___\///\\\______________\/\\\_____  
____\////\\\\\\\\\____\///\\\\\/_____\///\\\\\\\\\\\/______\////\\\\\\\\\__/\\\\\\\\\\\_ 
_______\/////////_______\/////_________\///////////___________\/////////__\///////////__


 _______________________/\\\________/\\\\\\\\\\_____________/\\\\\____________________
  ____________________/\\\\\______/\\\///////\\\________/\\\\////____________________
 ___________________/\\\/\\\_____\///______/\\\______/\\\///___________________________
  ________________/\\\/\/\\\____________/\\\//_____/\\\\\\\\\\\_______________________
 _______________/\\\/__\/\\\___________\////\\\___/\\\\///////\\\______________________
  ____________/\\\\\\\\\\\\\\\\___________\//\\\_\/\\\______\//\\\____________________
 ____________\///////////\\\//___/\\\______/\\\__\//\\\______/\\\___________________
   ____________________\/\\\____\///\\\\\\\\\/____\///\\\\\\\\\/______________________
  _____________________\///_______\/////////________\/////////______________________


    Exercise 22.7 (Min Heap)

    (Min-heap) The heap presented in the text is also known as a max-heap, in which
    each node is greater than or equal to any of its children. A min-heap is a heap
    in which each node is less than or equal to any of its children. Min-heaps are
    often used to implement priority queues. Revise the Heap class in Listing 23.9 to
    implement a min-heap.
            




    The following code is directly from the book: Only minor modifications were made
    to use MinHeap

    The areas where you see this in the code:
    /******************************************************/
/*  
    Are areas where I have edited the code to make it a min heap


    Output before modificaiton: 
        xdmtk@DMT~/prog/fall2018/lab8 (master)
        └─ $ ▶ java MinHeap 
        -44 -5 -4 -3 0 1 1 2 3 3 4 5 53 

    Output after modification
        dmtk@DMT~/prog/fall2018/lab8 (master)
        └─ $ ▶ java MinHeap 
        53 5 4 3 3 2 1 1 0 -3 -4 -5 -44 


*/

public class MinHeap<E extends Comparable<E>> {
    private java.util.ArrayList<E> list = new java.util.ArrayList<>();
    

    /** A test method */
    public static void main(String[] args) {
        Integer[] list = {-44, -5, -3, 3, 3, 1, -4, 0, 1, 2, 4, 5, 53};
        heapSort(list);

        for (int i = 0; i < list.length; i++)
            System.out.print(list[i] + " ");
    }





    /** Create a default heap */
    public MinHeap() {

    }

    /** Create a heap from an array of objects */
    public MinHeap(E[] objects) {
        for (int i = 0; i < objects.length; i++)
            add(objects[i]);
    }

    /** Add a new object into the heap */
    public void add(E newObject) {
        list.add(newObject); // Append to the heap
        int currentIndex = list.size() - 1; // The index of the last node

        while (currentIndex > 0) {
            int parentIndex = (currentIndex - 1) / 2;


/******************************************************/

            // Swap if the current object is LESS than its parent
            if (list.get(currentIndex).compareTo(list.get(parentIndex)) < 0) {

/******************************************************/
            
                E temp = list.get(currentIndex);
                list.set(currentIndex, list.get(parentIndex));
                list.set(parentIndex, temp);
            }
            else
                break; // The tree is a heap now

            currentIndex = parentIndex;
        }
    }

    /** Remove the root from the heap */
    public E remove() {
        if (list.size() == 0) return null;

        E removedObject = list.get(0);
        list.set(0, list.get(list.size() - 1));
        list.remove(list.size() - 1);

        int currentIndex = 0;
        while (currentIndex < list.size()) {
            int leftChildIndex = 2 * currentIndex + 1;
            int rightChildIndex = 2 * currentIndex + 2;

            // Find the maximum between two children
            if (leftChildIndex >= list.size()) break; // The tree is a heap
            
            int maxIndex = leftChildIndex;
            if (rightChildIndex < list.size()) {

/******************************************************/

                if (list.get(maxIndex).compareTo(list.get(rightChildIndex)) > 0) {

/******************************************************/
                    maxIndex = rightChildIndex;
                }
            }

            // Swap if the current node is less than the maximum

/******************************************************/

            if (list.get(currentIndex).compareTo(list.get(maxIndex)) > 0) {

/******************************************************/
                E temp = list.get(maxIndex);
                list.set(maxIndex, list.get(currentIndex));
                list.set(currentIndex, temp);
                currentIndex = maxIndex;
            }
            else
                break; // The tree is a heap
        }

        return removedObject;
    }

    /** Get the number of nodes in the tree */
    public int getSize() {
        return list.size();
    }

	
	
    public static <E extends Comparable<E>> void heapSort(E[] list) {
        // Create a Heap of integers
        MinHeap<E> heap = new MinHeap<>(); 
        
        // Add elements to the heap
        for (int i = 0; i < list.length; i++)
            heap.add(list[i]);

        // Remove elements from the heap
        for (int i = list.length - 1; i >= 0; i--)
            list[i] = heap.remove(); 
    }
}
